Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/how-to-send-email-from-localhost-in-php/

============ Instruction ============
1. Open the index.php file and change the SMTP username and password with your email address and Gmail password. 

2. Set From email, ReplyTo email and add a recipient email.

3. Insert HTML body content into the $bodyContent variable.

4. Run the index.php file on the browser and check recipient email account.


============ May I Help You ===========
If you have any query about this script, please feel free to comment here - http://www.codexworld.com/how-to-send-email-from-localhost-in-php/#respond. We will reply your query ASAP.